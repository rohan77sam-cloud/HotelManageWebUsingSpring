<%@ page import="org.hibernate.*" %>
<%@ page import="org.hibernate.query.Query" %>
<%@ page import="com.hotel.util.HibernateUtil" %>
<%@ page import="com.hotel.entity.RoomEntity" %>
<%@ page import="com.hotel.entity.FoodEntity" %>

<%@ page session="true" %>

<%
if(session.getAttribute("username")==null){

response.sendRedirect("login.jsp");

}
%>

<%

String username =
(String) session.getAttribute("username");

Session hibernateSession =
HibernateUtil
.getSessionFactory()
.openSession();

Query roomQuery =
hibernateSession.createQuery(
"from RoomEntity where username=:u"
);

roomQuery.setParameter("u",username);

RoomEntity room =
(RoomEntity) roomQuery.uniqueResult();

double roomPrice = 0;

if(room != null){

roomPrice = room.getPrice();

}

Query foodQuery =
hibernateSession.createQuery(
"select sum(price) from FoodEntity where username=:u"
);

foodQuery.setParameter("u",username);

Double foodPrice =
(Double) foodQuery.uniqueResult();

if(foodPrice == null){

foodPrice = 0.0;

}

double total = roomPrice + foodPrice;

session.setAttribute("totalAmount",total);

hibernateSession.close();

%>

<html>

<head>

<title>Payment</title>

<style>

body{
font-family:Arial;
background:linear-gradient(to right,#1d2671,#c33764);
text-align:center;
}

.container{
background:white;
width:500px;
margin:auto;
margin-top:100px;
padding:40px;
border-radius:20px;
box-shadow:0px 0px 15px black;
}

input{
width:80%;
padding:10px;
margin:20px;
font-size:18px;
}

button{
background:#c33764;
color:white;
padding:12px 25px;
border:none;
border-radius:10px;
font-size:18px;
}

h1{
color:#c33764;
}

</style>

</head>

<body>

<div class="container">

<h1>Payment Page</h1>

<h2>
Room Price : ₹<%= roomPrice %>
</h2>

<h2>
Food Price : ₹<%= foodPrice %>
</h2>

<h1>
Total Bill : ₹<%= total %>
</h1>

<form action="payment" method="post">

<input type="number"
       name="amount"
       placeholder="Enter Total Amount"
       required>

<br>

<button type="submit">
Pay Now
</button>

</form>

</div>

</body>

</html>