<html>

<head>

<title>Register</title>

<style>

body{
background:linear-gradient(to right,#ff9966,#ff5e62);
font-family:Arial;
text-align:center;
}

form{
background:white;
padding:30px;
width:350px;
margin:auto;
margin-top:100px;
border-radius:15px;
box-shadow:0px 0px 10px black;
}

input{
width:90%;
padding:10px;
margin:10px;
}

button{
background:orange;
color:white;
padding:10px 20px;
border:none;
border-radius:5px;
}

h1{
color:#ff5e62;
}

</style>

</head>

<body>

<form action="register" method="post">

<h1>Hotel Registration</h1>

<input type="text"
       name="username"
       placeholder="Enter Username"
       required>

<br>

<input type="password"
       name="password"
       placeholder="Enter Password"
       required>

<br><br>

<button type="submit">
Register
</button>

<br><br>

<a href="login.jsp">
Already Registered? Login
</a>

</form>

</body>

</html>