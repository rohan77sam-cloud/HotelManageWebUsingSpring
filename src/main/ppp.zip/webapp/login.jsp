<html>

<head>

<title>Login</title>

<style>

body{
background:linear-gradient(to right,#36d1dc,#5b86e5);
font-family:Arial;
text-align:center;
}

form{
background:white;
width:350px;
margin:auto;
margin-top:100px;
padding:30px;
border-radius:15px;
box-shadow:0px 0px 10px black;
}

input{
width:90%;
padding:10px;
margin:10px;
}

button{
background:#5b86e5;
color:white;
padding:10px 20px;
border:none;
border-radius:5px;
}

h1{
color:#5b86e5;
}

</style>

</head>

<body>

<form action="${pageContext.request.contextPath}/login"
      method="post">

<h1>Hotel Login</h1>

<input type="text"
       name="username"
       placeholder="Enter Username"
       required>

<br>

<input type="password"
       name="password"
       placeholder="Enter Password"
       required>

<br><br>

<button type="submit">
Login
</button>

</form>

</body>

</html>