<%
if(session.getAttribute("username")==null){

response.sendRedirect("login.jsp");

}
%>

<%@ page session="true" %>

<html>

<head>

<title>Room Booking</title>

<style>

body{
font-family:Arial;
background:linear-gradient(to right,#fc4a1a,#f7b733);
text-align:center;
}

.container{
display:flex;
flex-wrap:wrap;
justify-content:center;
}

.card{
background:white;
width:300px;
margin:20px;
padding:20px;
border-radius:20px;
box-shadow:0px 0px 10px black;
}

img{
width:100%;
height:200px;
border-radius:10px;
}

button{
background:#fc4a1a;
color:white;
padding:10px 20px;
border:none;
border-radius:10px;
font-size:18px;
}

h1{
color:white;
}

</style>

</head>

<body>

<h1>Book Your Luxury Room</h1>

<div class="container">

<!-- STANDARD ROOM -->

<div class="card">

<img src="images/standard.jpg">

<h2>Standard Room</h2>

<h3>₹2000</h3>

<form action="bookroom" method="post">

<input type="hidden"
       name="roomType"
       value="Standard">

<input type="hidden"
       name="price"
       value="2000">

<button type="submit">
Book Now
</button>

</form>

</div>

<!-- DELUXE ROOM -->

<div class="card">

<img src="images/deluxe.jpg">

<h2>Deluxe Room</h2>

<h3>₹4000</h3>

<form action="bookroom" method="post">

<input type="hidden"
       name="roomType"
       value="Deluxe">

<input type="hidden"
       name="price"
       value="4000">

<button type="submit">
Book Now
</button>

</form>

</div>

<!-- SUITE ROOM -->

<div class="card">

<img src="images/suite.jpg">

<h2>Suite Room</h2>

<h3>₹7000</h3>

<form action="bookroom" method="post">

<input type="hidden"
       name="roomType"
       value="Suite">

<input type="hidden"
       name="price"
       value="7000">

<button type="submit">
Book Now
</button>

</form>

</div>

<!-- QUAD ROOM -->

<div class="card">

<img src="images/quad.jpg">

<h2>Quad Room</h2>

<h3>₹9000</h3>

<form action="bookroom" method="post">

<input type="hidden"
       name="roomType"
       value="Quad">

<input type="hidden"
       name="price"
       value="9000">

<button type="submit">
Book Now
</button>

</form>

</div>

</div>

</body>

</html>