<%
if(session.getAttribute("username")==null){

response.sendRedirect("login.jsp");

}
%>

<%@ page session="true" %>

<html>

<head>

<title>Profile</title>

<style>

body{
font-family:Arial;
background:linear-gradient(to right,#00b09b,#96c93d);
text-align:center;
}

.container{
background:white;
width:600px;
margin:auto;
margin-top:50px;
padding:40px;
border-radius:20px;
box-shadow:0px 0px 15px black;
}

a{
display:block;
margin:20px;
padding:15px;
background:#00b09b;
color:white;
text-decoration:none;
border-radius:10px;
font-size:20px;
}

h1{
color:#00b09b;
}

</style>

</head>

<body>

<div class="container">

<h1>
Welcome
<%= session.getAttribute("username") %>
</h1>

<h2>
We are lucky to have you.
Please let us know how we may serve you.
</h2>

<a href="roombooking.jsp">
1. Room Booking
</a>

<a href="orderfood.jsp">
2. Order Food
</a>

<a href="payment.jsp">
3. Payment
</a>

<a href="logout">
4. Exit / Logout
</a>

</div>

</body>

</html>